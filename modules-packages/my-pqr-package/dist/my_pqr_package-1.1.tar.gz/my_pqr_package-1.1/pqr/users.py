
users = {
    "name":'Awnish',
    "age":27,
    "class":"Btech"
}

def getUser(key):
     return users[key]

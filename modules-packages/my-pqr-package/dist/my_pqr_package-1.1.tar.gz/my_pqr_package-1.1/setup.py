from setuptools import setup,find_packages

setup(
    name='my-pqr-package',
    description='''This Package is custom package with some functions''',
    version=1.01,
    packages=find_packages(),
    author='Awnish Kumar',
    author_email='awnishmmg.a41@gmail.com'
)
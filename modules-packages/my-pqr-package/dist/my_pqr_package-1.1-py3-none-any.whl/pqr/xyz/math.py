

#path : abc/xyz

def add(x,y):
    return x+y

def multi(x,y):
    return x*y


print('This pqr file will automatically during import of the package')
